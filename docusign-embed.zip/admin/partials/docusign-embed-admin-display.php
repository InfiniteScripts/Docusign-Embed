<?php

/**
 * Admin Area
 *
 * @link       http://www.infinitescripts.com/docusign-embed
 * @since      1.0.0
 *
 * @package    docusign_embed
 * @subpackage docusign_embed/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
